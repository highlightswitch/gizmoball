package view;

public class ChangeFrictionDialogue {
}
