package view;

public class EditBallDialogue {
}
