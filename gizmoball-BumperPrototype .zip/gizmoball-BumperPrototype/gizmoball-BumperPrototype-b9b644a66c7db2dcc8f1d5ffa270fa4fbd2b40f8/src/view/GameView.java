package view;

import javax.swing.*;

public interface GameView {
   JPanel getPanel();
}
