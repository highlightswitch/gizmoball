package model.gizmo;

public interface Tickable {
    void tick();
}
