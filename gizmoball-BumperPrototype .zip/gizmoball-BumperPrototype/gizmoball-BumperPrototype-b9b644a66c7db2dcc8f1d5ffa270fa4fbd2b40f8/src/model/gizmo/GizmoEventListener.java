package model.gizmo;

public interface GizmoEventListener {
    void keyDown();
    void keyUp();
    void genericTrigger();
}
