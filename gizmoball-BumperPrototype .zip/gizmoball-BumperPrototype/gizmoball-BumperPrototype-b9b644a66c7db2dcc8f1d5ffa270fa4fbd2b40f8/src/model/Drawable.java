package model;

public interface Drawable {

    GameObject getShapeToDraw(); //TODO: This should return a sprite of some sort eventually

}
