Gizmoball Key Deadlines
1. Revised Spec
2. Use Cases
3. Class Diagram
4. GUI drawings
5. Physical Loop and Triggering system description 
6. project plan
7. testing strategy
8. 4 prototypes