package view;

public class EditAbsorberDialogue {
}
