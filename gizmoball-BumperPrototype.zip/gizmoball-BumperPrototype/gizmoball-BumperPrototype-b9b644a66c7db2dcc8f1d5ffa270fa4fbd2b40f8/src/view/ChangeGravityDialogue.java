package view;

public class ChangeGravityDialogue {
}
