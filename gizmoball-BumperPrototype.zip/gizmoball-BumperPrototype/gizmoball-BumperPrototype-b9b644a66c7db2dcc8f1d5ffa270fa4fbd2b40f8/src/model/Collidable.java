package model;

public interface Collidable {
    GameObject getGameObject();
}
