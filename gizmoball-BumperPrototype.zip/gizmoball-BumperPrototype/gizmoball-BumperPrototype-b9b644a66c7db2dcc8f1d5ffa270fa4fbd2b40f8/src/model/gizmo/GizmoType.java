package model.gizmo;

public enum GizmoType {
    FLIPPER, BALL, CIRCLE_BUMPER,SQUARE_BUMPER,TRIANGLE_BUMPER;
}
