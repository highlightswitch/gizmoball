package model.gizmo;

public enum BumperType {
    Square, Triangle, Circle
}
