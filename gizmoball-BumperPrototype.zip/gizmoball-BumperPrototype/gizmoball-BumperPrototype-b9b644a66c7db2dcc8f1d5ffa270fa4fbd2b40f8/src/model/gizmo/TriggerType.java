package model.gizmo;

public enum  TriggerType {
    KEY_DOWN, KEY_UP, GENERIC;
}
